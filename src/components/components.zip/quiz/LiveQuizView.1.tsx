import React from 'react'

const LiveQuizView = () => {
  return (
    <div>
      <h2>LiveQuiz View</h2>
      <p>This is a placeholder for the LiveQuizView view.</p>
    </div>
  )
}

export default LiveQuizView
