import React, { useEffect } from 'react'
import { useQuiz } from '../context/QuizContext'
import { saveQuizResult } from '../utils/saveResult'
import { useNavigate } from 'react-router-dom'

const ResultScreen = () => {
  const { correctAnswers, questions, selectedTopic, userId, resetQuiz } = useQuiz()
  const navigate = useNavigate()

  useEffect(() => {
    if (selectedTopic && userId) {
      saveQuizResult(userId, selectedTopic.id, {
        correctAnswers,
        totalQuestions: questions.length,
        timestamp: new Date().toISOString(),
      })
    }
  }, [correctAnswers, questions, selectedTopic, userId])

  const handleRestart = () => {
    resetQuiz()
    navigate('/')
  }

  return (
    <div>
      <h2>Quiz Complete</h2>
      <p>Score: {correctAnswers} / {questions.length}</p>
      <button onClick={handleRestart}>Back to Topics</button>
    </div>
  )
}

export default ResultScreen
