import React from 'react'
import { useQuiz } from '../../context/QuizContext'
import { useNavigate } from 'react-router-dom'
import quizTopics from '../../data/quizTopics'

const QuizTopicsScreen = () => {
  const { selectTopic } = useQuiz()
  const navigate = useNavigate()

  const handleSelect = (topic: any) => {
    selectTopic(topic)
    navigate('/quiz')
  }

  return (
    <div>
      <h2>Select a Quiz Topic</h2>
      <ul>
        {quizTopics.map(topic => (
          <li key={topic.id} onClick={() => handleSelect(topic)} style={{ cursor: 'pointer', marginBottom: '10px' }}>
            <strong>{topic.title}</strong>: {topic.description}
          </li>
        ))}
      </ul>
    </div>
  )
}

export default QuizTopicsScreen
