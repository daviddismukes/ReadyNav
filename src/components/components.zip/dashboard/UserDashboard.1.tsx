import React from 'react'

const UserDashboard = () => {
  return (
    <div>
      <h2>User Dashboard</h2>
      <p>This is a placeholder for the UserDashboard view.</p>
    </div>
  )
}

export default UserDashboard
